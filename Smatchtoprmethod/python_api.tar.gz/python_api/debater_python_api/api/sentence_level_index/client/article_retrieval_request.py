# (C) Copyright IBM Corp. 2020.


class ArticleRetrievalRequest():
    def __init__(self, articleIds):
        self.articleIds = articleIds


